# Survival Duration Calculator

## Project Description

The Survival Duration Calculator is a simple Python project designed to calculate the duration of time a person has lived based on their age in various time units. The available time units are Months, Weeks, Days, Hours, Minutes, and Seconds. The user is prompted to enter their age and select a time unit, and the program outputs the duration in the chosen time unit.

## Thoughts During Project Creation

### Objective
The main goal was to create a user-friendly program that accurately converts age into different time units. I aimed to make the interaction simple and intuitive, allowing users to input their age and choose their preferred time unit with ease.

### Implementation
1. **Function `duration_calculator`**:
    - This function is responsible for converting the age into the specified time unit. It checks the input time unit and performs the corresponding calculation.
    - I used a dictionary-like approach with `if-elif` statements to handle different time units and ensure the correct conversion.

2. **Function `main`**:
    - The `main` function handles user input and output. It prompts the user for their age and the desired time unit, then calls `duration_calculator` to compute the duration.
    - Basic error handling is included to manage invalid inputs, such as non-integer age values and invalid time units.

3. **Error Handling**:
    - The program includes checks for negative ages and invalid time units, providing appropriate messages to guide the user.

### Future Enhancements
- Add more detailed error messages and input validation.
- Expand the program to handle leap years in the calculation.
- Create a graphical user interface (GUI) for better user experience.

## How to Run

1. Make sure you have Python installed on your machine.
2. Clone the repository from GitHub.
3. Navigate to the project directory and run the script:
    ```sh
    python survival_duration_calculator.py
    ```
4. Follow the prompts to enter your age and choose a time unit.
